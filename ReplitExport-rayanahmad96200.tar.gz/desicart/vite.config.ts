import { defineConfig } from "@lovable.dev/vite-tanstack-config";

// The lovable-plugin intercepts `react/jsx-dev-runtime` and replaces it with a
// virtual module that adds DOM ref tracking for Lovable's visual editor.
// In non-Lovable environments (Replit) this causes SSR hydration mismatches and
// "Invalid hook call" errors: the tagger adds ref props on the client that were
// absent during SSR. We neutralise its resolveId / load hooks in configResolved.
function bypassLovableTagger() {
  return {
    name: "bypass-lovable-tagger",
    configResolved(config: any) {
      for (const plugin of config.plugins) {
        if (plugin.name === "lovable-plugin") {
          plugin.resolveId = undefined;
          plugin.load = undefined;
        }
      }
    },
  };
}

export default defineConfig({
  vite: {
    plugins: [bypassLovableTagger()],
    server: {
      host: "0.0.0.0",
      port: 5000,
      strictPort: true,
      allowedHosts: true,
    },
  },
});

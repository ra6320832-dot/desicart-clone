# DesiCart

A Pakistani e-commerce storefront built with TanStack Start (React + Vite SSR). Sells premium tech products — smartwatches, earbuds, headphones, speakers, and power banks — with WhatsApp-based ordering.

## Stack

- **Framework**: TanStack Start (TanStack Router + React 19 + Vite 7)
- **Styling**: Tailwind CSS v4 + shadcn/ui (Radix UI components)
- **Language**: TypeScript
- **Package Manager**: npm (lockfile present; bun.lockb also exists but npm is used in scripts)
- **Vite Config**: `@lovable.dev/vite-tanstack-config` wraps all plugins

## Project Layout

```
src/
  routes/         # File-based routes (TanStack Router)
    __root.tsx    # Root layout with HTML shell
    index.tsx     # Homepage (hero slider, products grid)
    product.$slug.tsx  # Product detail page
  components/     # Shared UI components
    CustomerOrderForm.tsx
    ui/           # shadcn/ui components
  lib/            # Product data & utilities
  hooks/          # Custom React hooks
  assets/         # Product images (PNG)
  styles.css      # Global Tailwind styles
  router.tsx      # Router factory
  routeTree.gen.ts  # Auto-generated route tree
app.js / server.mjs  # Node.js production HTTP server (bridges Node to Web Fetch API)
vite.config.ts    # Dev config (port 5000, host 0.0.0.0)
vite.config.prod.ts  # Production config (Node SSR target, no Cloudflare)
```

## Development

```bash
npm run dev      # Start Vite dev server on port 5000
npm run build    # Build for production (Hostinger static export)
npm start        # Run production server
```

## Workflow

- **Start application**: `npm run dev` → port 5000 (webview)

## Deployment

- **Target**: autoscale
- **Build**: `npm run build:dev`
- **Run**: `node app.js`

## Key Notes

- Vite dev server configured for `host: "0.0.0.0"`, `port: 5000`, `allowedHosts: true` to work behind Replit's proxy
- The `@lovable.dev/vite-tanstack-config` package bundles TanStack Start, React, Tailwind, tsconfig paths, and other plugins — do NOT add them manually
- WhatsApp ordering links use phone number `923214028277`
